package com.jkapps.cardviewwithrecyclerview;

public class Data {

    static Integer[] drawableArray = {R.drawable.food1, R.drawable.food2,
            R.drawable.food1, R.drawable.giftcard, R.drawable.food3};

    static String[] titleArray = {"ITEM 1", "ITEM 2", "ITEM 3", "ITEM 4", "ITEM 5"};

    static String[] descriptionArray = {"Item 1 Description...",
            "Item 2 Description... Description... Description... Description... Description... Description... Description...",
            "Item 3 Description...",
            "Item 4 Description...",
            "Item 5 Description... Description... Description... Description... Description... Description... Description..."
    };

}